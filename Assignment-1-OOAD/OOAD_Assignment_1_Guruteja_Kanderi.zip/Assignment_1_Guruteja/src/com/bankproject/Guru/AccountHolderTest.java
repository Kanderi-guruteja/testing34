package com.bankproject.Guru;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

public class AccountHolderTest {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        //Set interest rate to 4%
        AccountHolder.annualInterestRate = 0.04;
        //declaringb the variable
        AccountHolder accountHolder;
        double balance = 0.0, deposit = 0.0, withdrawal = 0.0;

        // Prompt user to enter initial balance, repeat until a positive value is entered
        while (true) {
            System.out.println("Please enter the initial balance:");
            try {
                balance = Double.parseDouble(sc.nextLine());
                if (balance < 0) {
                    System.out.println("Error: Balance cannot be negative. Please enter a positive beginning balance.");
                } else {
                    break;
                }
              //Executes this catch function if user gives negative values in Initial Balance 
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number for balance.");
            }
        }
        accountHolder = new AccountHolder(balance);

        // Prompt user to enter deposit amount, repeat until a positive value is entered
        while (true) {
            System.out.println("Please enter the amount to be deposited:");
            try {
                deposit = Double.parseDouble(sc.nextLine());
                if (deposit <= 0) {
                    System.out.println("Deposit amount should not be negative or zero. Please enter a positive non-zero value for deposit.");
                } else {
                    break;
                }
              //Executes this catch function if user gives negative values in deposit 
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number for deposit.");
            }
        }
        accountHolder.deposit(deposit);

        // Prompt user to enter withdrawal amount, repeat until a positive value is entered
        while (true) {
            System.out.println("Please enter the amount to be withdrawn:");
            try {
                withdrawal = Double.parseDouble(sc.nextLine());
                if (withdrawal <= 0) {
                    System.out.println("Withdrawal amount cannot be negative or zero. Enter a positive non-zero value for withdrawal.");
                } else if (withdrawal > accountHolder.getBalance()) {
                    System.out.format("Withdrawal amount should not be higher than account balance. Enter the withdrawal amount within account balance. Your balance: $%.2f%n", accountHolder.getBalance());
                } else {
                    break;
                }
                //Executes this catch function if user gives negative values in withdrawal 
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid number for withdrawal.");
            }
        }
        accountHolder.withdraw(withdrawal);

        accountHolder.monthlyInterest();
        //Prints New balance after adding interest for 12 months to the original balance
        System.out.println("New balance after one year with interest: $" + accountHolder.getBalance());
        //Prints date and programmer's name at the end
        String timeStamp = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss").format(Calendar.getInstance().getTime()); 
        System.out.print("Current date & time =" + timeStamp + "\nProgrammed by Guruteja\tkanderi\n");

        sc.close(); // close the scanner object
    }
}
