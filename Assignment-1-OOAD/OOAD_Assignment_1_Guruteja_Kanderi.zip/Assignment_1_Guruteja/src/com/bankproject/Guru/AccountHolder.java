package com.bankproject.Guru;
import java.util.Scanner;
public class AccountHolder {
    public static double annualInterestRate;
     double balance;
     Scanner sc = new Scanner(System.in);

    public AccountHolder(double balance) {
        while (balance < 0) {
            System.out.println("Balance amount cannot be negative. Please enter a positive value: ");
         //Takes input from user and throws error if user gives negative value
            balance = sc.nextDouble();
        }
        this.balance = balance;
    }

    public void deposit(double depositAmount) {
        while (depositAmount <= 0) {
        	//Checks if value is greater than or equal to zero and throws error to re-enter the value
            System.out.println("Deposit amount should not be negative or zero. Please, reenter a positive non-zero value for deposit: ");
            Scanner sc = new Scanner(System.in);
            depositAmount = sc.nextDouble();
        }
        //Here the balnce will be updated with deposit amount
        balance += depositAmount;
    }

    public void withdraw(double withdrawalAmount) {
        while (withdrawalAmount <= 0) {
            System.out.println("Withdrawal amount cannot be negative or zero. Enter a positive non-zero value for withdrawal: ");
            withdrawalAmount = sc.nextDouble();
        }
        if (balance - withdrawalAmount < 50) {
            System.out.println("Withdraw request cannot be processed - balance will drop below $50" + "\n" + "balance: " + balance);
        } else {
        	//Here the balance will deducted from withdrawal amount
            balance -= withdrawalAmount;
        }
    }

    public void monthlyInterest() {
        double monthlyInterest = annualInterestRate / 12.0;
        System.out.println("Month\t\tNew Balance");
        double balanceAtBeginning = balance;
        //The iteration starts for 12 months interest and prints it in the console
        for (int i = 1; i <= 12; i++) {
            balance += balance * monthlyInterest;
            if (i == 1) {
            	//Here the initial balance will print before executing the monthly updated balance+interest rate
                System.out.println("Base\t\t$" + balanceAtBeginning);
            }
            //Here it prints the final balance after adding interest for 12 months
            System.out.println(i + "\t\t$" + balance);
        }
    }

    public double getBalance() {
        return balance;
    }
}
